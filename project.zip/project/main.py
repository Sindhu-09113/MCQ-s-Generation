from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import fitz  # PyMuPDF
import nltk
from transformers import pipeline
from pydantic import BaseModel
import uvicorn
import io
import textwrap
import random
from sentence_transformers import SentenceTransformer, util
import docx  # For DOCX files
import os

nltk.download("punkt")

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load models
question_generator = pipeline("text2text-generation", model="valhalla/t5-base-qg-hl")
answer_generator = pipeline("question-answering", model="deepset/roberta-base-squad2")
similarity_model = SentenceTransformer("BAAI/bge-small-en-v1.5")

class MCQResponse(BaseModel):
    mcqs: list[dict]

def extract_text_from_pdf(pdf_bytes):
    try:
        doc = fitz.open(stream=io.BytesIO(pdf_bytes), filetype="pdf")
        text = " ".join([page.get_text("text") for page in doc])
        if not text.strip():
            raise ValueError("No extractable text found in PDF.")
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"PDF extraction error: {str(e)}")

def extract_text(file: UploadFile, content: bytes):
    filename = file.filename.lower()

    if filename.endswith(".pdf"):
        return extract_text_from_pdf(content)
    elif filename.endswith(".txt"):
        try:
            return content.decode("utf-8")
        except UnicodeDecodeError:
            raise HTTPException(status_code=400, detail="Unable to decode text file.")
    elif filename.endswith(".docx"):
        try:
            doc = docx.Document(io.BytesIO(content))
            return "\n".join([para.text for para in doc.paragraphs])
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error reading DOCX file: {str(e)}")
    else:
        raise HTTPException(status_code=400, detail="Unsupported file type.")

def generate_questions(text):
    sentences = nltk.sent_tokenize(text)
    if not sentences:
        raise ValueError("No valid sentences found for question generation.")
    
    questions = set()
    for sentence in sentences:
        q = question_generator(
            f"generate a meaningful question about: {sentence}",
            max_length=50,
            num_return_sequences=1
        )
        generated_question = q[0]['generated_text'].strip()
        if generated_question.endswith("?") and len(generated_question) > 10:
            questions.add(generated_question)
    
    return list(questions)

def chunk_text(text, chunk_size=512):
    return textwrap.wrap(text, width=chunk_size)

def generate_distractors(correct_answer, text, num_distractors=3):
    try:
        sentences = nltk.sent_tokenize(text)
        context_words = set(word for sentence in sentences for word in sentence.split() if word.lower() != correct_answer.lower())
        distractors = set()

        if correct_answer in context_words:
            context_words.remove(correct_answer)

        if context_words:
            similar_words = similarity_model.encode([correct_answer])
            corpus_embeddings = similarity_model.encode(list(context_words))
            word_scores = util.semantic_search(similar_words, corpus_embeddings, top_k=num_distractors+10)

            for score in word_scores[0]:
                candidate = list(context_words)[score['corpus_id']]
                if candidate.lower() != correct_answer.lower() and candidate not in distractors:
                    distractors.add(candidate)

        while len(distractors) < num_distractors:
            distractors.add(f"{correct_answer} in another context")

        return random.sample(list(distractors), min(len(distractors), num_distractors))
    except Exception:
        return [
            f"{correct_answer} but different meaning",
            f"{correct_answer} reworded",
            f"{correct_answer} with a twist"
        ]

def generate_mcqs(text, questions):
    mcqs = []
    text_chunks = chunk_text(text)

    for question in questions:
        best_answer = ""
        best_score = 0

        for chunk in text_chunks:
            answer = answer_generator(question=question, context=chunk)
            if answer["score"] > best_score and len(answer["answer"]) > 1:
                best_answer = answer["answer"]
                best_score = answer["score"]

        if not best_answer or best_score < 0.3:
            continue

        distractors = generate_distractors(best_answer, text)
        options = [best_answer] + distractors
        random.shuffle(options)

        mcqs.append({
            "question": question,
            "options": options,
            "correct_answer": best_answer
        })

    return mcqs

@app.post("/upload-pdf", response_model=MCQResponse)
async def upload_pdf(file: UploadFile = File(...)):
    try:
        content = await file.read()
        if not content:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")

        text = extract_text(file, content)
        questions = generate_questions(text)
        mcqs = generate_mcqs(text, questions)

        return {"mcqs": mcqs}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
