import React, { useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [file, setFile] = useState(null);
  const [mcqs, setMcqs] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      alert("Please select a file.");
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post("http://127.0.0.1:8000/upload-pdf", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMcqs(response.data.mcqs);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Failed to upload the file.");
    }
    setLoading(false);
  };

  const handleDownload = () => {
    if (mcqs.length === 0) return;

    let text = "Generated MCQs:\n\n";
    mcqs.forEach((mcq, index) => {
      text += `Q${index + 1}: ${mcq.question}\n`;
      mcq.options.forEach((option, i) => {
        text += `  ${String.fromCharCode(65 + i)}. ${option}\n`;
      });
      text += `✅ Answer: ${mcq.correct_answer}\n\n`;
    });

    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "mcqs.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container">
      <div className="upload-section">
        <h1>📄 MCQ Generator</h1>
        <input
          type="file"
          onChange={handleFileChange}
          accept=".pdf,.txt,.doc,.docx"
          className="file-input"
        />
        <button onClick={handleUpload} disabled={loading} className="upload-btn">
          {loading ? "Uploading..." : "Upload & Generate MCQs"}
        </button>
        {mcqs.length > 0 && (
          <button onClick={handleDownload} className="download-btn">
            ⬇️ Download as .txt
          </button>
        )}
      </div>

      {mcqs.length > 0 && (
        <div className="mcq-container">
          <h2>📝 Generated MCQs</h2>
          {mcqs.map((mcq, index) => (
            <div className="mcq-card" key={index}>
              <p className="mcq-question">
                <strong>Q{index + 1}:</strong> {mcq.question}
              </p>
              <ul className="mcq-options">
                {mcq.options.map((option, i) => (
                  <li key={i} className="mcq-option">{option}</li>
                ))}
              </ul>
              <p className="mcq-answer">✅ Correct Answer: {mcq.correct_answer}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
